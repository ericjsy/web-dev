function drop() {
	document.getElementById("thisDropdown").classList.toggle("show");
}